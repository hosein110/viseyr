<?php

namespace App\Http\Controllers\web;

use App\Location;
use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Input;

class locationController extends Controller
{

    public function locationShow($location_id){

        $result = Location::leftjoin('users', 'users.id', '=', 'locations.user_id')
            ->leftjoin('location_likes', 'locations.id', '=', 'location_likes.location_id')
            ->leftjoin('location_comments', 'locations.id', '=', 'location_comments.location_id')
            ->leftjoin('location_rates', 'locations.id', '=', 'location_rates.location_id')
            ->leftjoin('states', 'locations.state_id', '=', 'states.id')
            ->leftjoin('cities', 'locations.city_id', '=', 'cities.id')
            ->leftjoin('posts', 'posts.location_id', '=', 'locations.id')
            ->select(
                'locations.id as id',
                'locations.name as location_name',
                'locations.lat as lat',
                'locations.longitude as long',
                'locations.tel as tel',
                'locations.price as price',
                'states.name as state',
                'cities.name as city',
                DB::raw("ifnull(cast(avg(posts.ptotal) as decimal(6,2)),0) as avg_ptotal "),
                DB::raw("count(DISTINCT(location_likes.id)) as likes_count"),
                DB::raw("count(DISTINCT(location_comments.id)) as comments_count"),
                DB::raw("count(DISTINCT(posts.user_id)) as people_posted"),
                DB::raw("ifnull(cast(avg(location_rates.rate) as decimal(6,2)),0) as avg_rate ")
            )
            ->with('images')
            ->with('transfers')
            ->with('entertainments')
            ->with(array("posts.user" => function ($q) {

                return $q->distinct()->select('id', 'image_path');
            }))
            ->with(array("transfers" => function ($q) {
                return $q->where('possibilities.type', 0);
            }))
            ->with(array("entertainments" => function ($q) {
                return $q->where('possibilities.type', 1);
            }))
            ->with('infos')
            ->with('work_time')
            ->where('locations.id', $location_id)
            ->groupBy("locations.id")
            ->get();


        return $result;
    }

    public function locations(){
        $state_id = Input::get('state_id', '0');
        $category_id = Input::get('category_id', '0');
        $orderBY = Input::get('orderBy', 'null');
        $latitude = Input::get('lat', 'null');
        $longitude = Input::get('long', 'null');

        $result = Location::leftjoin('location_rates', 'locations.id', '=', 'location_rates.location_id')
            ->leftjoin('states', 'locations.state_id', '=', 'states.id')
            ->leftjoin('cities', 'locations.city_id', '=', 'cities.id')
            ->leftjoin('posts', 'posts.location_id', '=', 'locations.id')
            ->leftjoin('location_possibility', 'location_possibility.location_id', '=', 'locations.id')
            ->select(
                'locations.id as id',
                'locations.name as location_name',
                'locations.tel as tel',
                'locations.price as price',
                'states.name as state',
                'cities.name as city',

                DB::raw("ifnull(cast(avg(location_rates.rate) as decimal(6,2)),0) as avg_rate "),
                DB::raw("ifnull(cast(avg(posts.ptotal) as decimal(6,2)),0) as avg_ptotal ")

            )
            ->with(array("posts.user" => function ($q) {

                return $q->distinct()->select('id', 'image_path');
            }))
            ->with('work_time')
            ->with('possibilities')
            ->with('images')
            ->withCount('likes')
            ->OrderByKeyword($orderBY)
            ->SearchByState($state_id)
            ->SearchByCategory($category_id)
            ->Distance($latitude, $longitude)
            ->groupBy("locations.id")
            ->paginate(5);


        return $result;
    }


}
