<?php

namespace App\Http\Controllers\web;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class userController extends Controller
{

    public function get_profile(Request $request)
    {
//        $other_user_id = $request->other_user_id;
//        $user_id = token2user($request->username);
//
//        $user =  User::select('id', 'image_path', 'fullname', 'bio','username')
//            ->where('id', $other_user_id)
//            ->first();
//
//        $check_follow = Follow::where('user_id', $user_id)->where('follower_id', $other_user_id)->first();
//
//        $user['follow_status'] = 0;
//        if (isset($check_follow)) {
//            if ($check_follow->accept == 1) {
//                $user['follow_status'] = 2;
//
//            } else {
//                $user['follow_status'] = 1;
//
//            }
//        }
//
//        $user['following_count'] = Follow::where('user_id', $other_user_id)->count();
//
//        $user['follower_count'] = Follow::where('follower_id', $other_user_id)->count();
//
//        $following = Follow::where('user_id', $user_id)
//            ->where('follower_id', $other_user_id)
//            ->where('accept', 1)
//            ->count();
//
//        $user['posts_count'] = Post::where('user_id', $other_user_id)->count();
//
//        if (!is_public($other_user_id)) {
//
//            if ($following) {
//                $user['can_visit'] = 1;
//                $user['post'] = Post::where('user_id', $other_user_id)->select('id')->with('image')->orderBy('id', 'DESC')->paginate(3);
//
//            } else {
//                $user['can_visit'] = 0;
//                $user['post'] = null;
//            }
//
//
//        } else {
//            $user['can_visit'] = 1;
//            $user['post'] = Post::where('user_id', $other_user_id)->select('id')->with('image')->orderBy('id', 'DESC')->paginate(3);
//
//        }

        return 2;
        return $user;
    }


}
